<?php
/*
Dasturchi: @VisualCoderUz
kod @SupperCoderUz kanalida tarqatildi

Manbaga tegilmasin.
*/

if (!file_exists('madeline.php')) {
    copy('https://phar.madelineproto.xyz/madeline.php', 'madeline.php');
}
include 'madeline.php';

$wk = "danog\MadelineProto\API";

$VisualCoderUz = new $wk('session.madeline');
$VisualCoderUz->start();
$time = date("H:i",strtotime("2 hour"));
$kun = date("d.m.Y",strtotime("2 hour"));

$obhicon = array('01d'=>'☀','02d'=>'🌤','03d'=>'☁️','04d'=>'🌥','09d'=>'🌦','10d'=>'🌧','11d'=>'⛈','13d'=>'❄️','50d'=>'💨','01n'=>'🌙','02n'=>'☁️','03n'=>'☁️','04n'=>'🌩','09n'=>'🌧','10n'=>'🌧','11n'=>'⛈','13n'=>'❄️','50n'=>'💨');
$obh = json_decode(file_get_contents("https://api.openweathermap.org/data/2.5/weather?q=Toshkent,UZ&units=metric&appid=a9d86a9dc54f8caf39ac424735ffc2e6"),true);
$obhavo = $obh['main']['temp'];
$icon = $obh['weather'][0]['icon'];

$bio = ["⏰ Soat - $time, $obhicon[$icon] Ob-Havo - $obhavo °C"];
$biorand = array_rand($bio);
$biotxt = "$bio[$biorand]";
$VisualCoderUz->account->updateProfile(['about'=>"$biotxt"]);
unlink("MadelineProto.log");

?>