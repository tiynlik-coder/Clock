<?php
/*
Dasturchi: @VisualCoderUz
kod @SupperCoderUz kanalida tarqatildi

Manbaga tegilmasin.
*/

if (!file_exists('madeline.php')) {
    copy('https://phar.madelineproto.xyz/madeline.php', 'madeline.php');
}
include 'madeline.php';

$wk = "danog\MadelineProto\API";

$nikim = file_get_contents("nik.txt");

$VisualCoderUz = new $wk('session.madeline');
$VisualCoderUz->start();
$time = date("H:i",strtotime("2 hour"));
$timer = date("H:i",strtotime("2 hour"));
$kun = date("d.m.Y",strtotime("2 hour"));
$time = str_replace('1', '¹', $time);
$time = str_replace('2', '²', $time);
$time = str_replace('3', '³', $time);
$time = str_replace('4', '⁴', $time);
$time = str_replace('5', '⁵', $time);
$time = str_replace('6', '⁶', $time);
$time = str_replace('7', '⁷', $time);
$time = str_replace('8', '⁸', $time);
$time = str_replace('9', '⁹', $time);
$time = str_replace('0', '⁰', $time);
$time = str_replace(':', '∶', $time);

$obhicon = array('01d'=>'☀','02d'=>'🌤','03d'=>'☁️','04d'=>'🌥','09d'=>'🌦','10d'=>'🌧','11d'=>'⛈','13d'=>'❄️','50d'=>'💨','01n'=>'🌙','02n'=>'☁️','03n'=>'☁️','04n'=>'🌩','09n'=>'🌧','10n'=>'🌧','11n'=>'⛈','13n'=>'❄️','50n'=>'💨');
$obh = json_decode(file_get_contents("https://api.openweathermap.org/data/2.5/weather?q=Toshkent,UZ&units=metric&appid=a9d86a9dc54f8caf39ac424735ffc2e6"),true);
$obhavo = $obh['main']['temp'];
$icon = $obh['weather'][0]['icon'];

$nik = ["$time | $nikim | $time"];
$nikrand = array_rand($nik);
$niktxt = "$nik[$nikrand]";
$bio = ["⏰ Soat - $timer, $obhicon[$icon] Ob-Havo - $obhavo °C"];
$biorand = array_rand($bio);
$biotxt = "$bio[$biorand]";
$VisualCoderUz->account->updateProfile(['first_name'=>"$niktxt",'about'=>"$biotxt"]);
unlink("MadelineProto.log");

?>