<?php
/*
Dasturchi: @VisualCoderUz
kod @SupperCoderUz kanalida tarqatildi

Manbaga tegilmasin.
*/

if (!file_exists('madeline.php')) {
    copy('https://phar.madelineproto.xyz/madeline.php', 'madeline.php');
}
include 'madeline.php';

$wk = "danog\MadelineProto\API";

$VisualCoderUz = new $wk('session.madeline');
$VisualCoderUz->start();

$VisualCoderUz->account->updateStatus(['offline' => false ]);

unlink("MadelineProto.log");

?>