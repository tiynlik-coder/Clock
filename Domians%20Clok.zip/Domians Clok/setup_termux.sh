#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg update -y
pkg install -y php curl unzip
for d in pul info ban step tizim odam tugma baza oplata; do mkdir -p "$d"; done
chmod 700 .
echo "Tayyor: PHP va kerakli papkalar sozlandi."
echo "Eslatma: Telegram webhook uchun ommaviy HTTPS hosting kerak; bu skript botni internetga joylamaydi."
