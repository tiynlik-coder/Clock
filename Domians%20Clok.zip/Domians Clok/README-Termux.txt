DOMIANS CLOK — Termux tayyorlash

1) Termux’da ZIP’ni Download papkasiga saqlang.
2) Buyruqlar:
   termux-setup-storage
   pkg update
   pkg install php curl unzip
   mkdir -p ~/DomiansClok
   cd ~/DomiansClok
   unzip ~/storage/downloads/"Domians Clok.zip"
   cd "Domians Clok"
   bash setup_termux.sh

XAVFSIZLIK / SOZLASH:
- Bot tokeni va admin ID koddan olib tashlangan. Ularni ZIP ichiga yozmang.
- Sozlash uchun o‘z serveringizda BOT_TOKEN va ADMIN_ID muhit o‘zgaruvchilarini bering.
- Bu PHP webhook qabul qiluvchi skript: oddiy `php Soatbot.php` buyrug‘i Telegram botni mustaqil onlayn qilmaydi. Telegram webhook uchun ommaviy HTTPS manzilli hosting kerak.
- Termux’dagi localhost Telegram serverlaridan webhook so‘rovlarini qabul qila olmaydi; lokal test uchun alohida tunnel/HTTPS sozlamasi zarur.
- `myxosting.suppercoders.uz/cron.php` ga so‘rov yuborish funksiyasi olib tashlangan.
- Fayllarda boshqa tashqi xizmatlar yoki eski kod bo‘lishi mumkin; ishga tushirishdan oldin ko‘zdan kechiring.
- ZIP ichida maxfiy token/admin ID saqlanmaydi.
